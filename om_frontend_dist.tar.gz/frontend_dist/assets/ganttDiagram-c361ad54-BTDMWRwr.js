import{a as Ee,s as Se,o as De,p as Ae,b as Ie,c as Fe,g as it,d as ht,e as Me,l as bt,k as Le,j as Ve,r as We,u as Ne}from"./GenericAgentWelcome-BRV6CKBA.js";import{d as N}from"./dayjs.min-q_9h1cPi.js";import{p as Pe}from"./index-Dr1FW_sl.js";import{d as Oe,a as ze}from"./customParseFormat-DqiwsQD4.js";import{t as Re,m as Ye,a as Be,b as Ht,c as Ut,d as qe,e as je,f as Xe,g as He,h as Ue,i as Ge,j as Ke,k as Gt,l as Kt,n as Zt,s as Jt,o as Qt}from"./time-BuzZT1VW.js";import{l as Ze}from"./linear-DU0cfXsz.js";import{R as ne,r as Je,l as se,n as re,C as ae,o as _t,q as Qe}from"./tiny-invariant-xUvDzYub.js";import"./clsx-B-dksMZM.js";import"./kbApi-BDtR4Bey.js";import"./fileApi-LrpYmink.js";import"./Table-iXV1U9W6.js";import"./index-BVAOAAsb.js";import"./index-BBML0aEC.js";import"./DownloadOutlined-CRxE-9W1.js";import"./index-_yIvtq1o.js";import"./index-DRkAVBuT.js";import"./Collapse-CBPvQOWg.js";import"./InfoCircleOutlined-Dk0LEwpa.js";import"./index-CQCwZfr6.js";import"./SOPFormModal-BS6mY7D8.js";import"./formatTime-BdfaZ4Al.js";import"./DatabaseOutlined-C4Wcu_Ea.js";import"./SettingOutlined-YeQy01UW.js";import"./threadApi-ffLiteu-.js";import"./ExclamationCircleOutlined-Du8L6lD5.js";import"./CompressOutlined-BbtujUdz.js";import"./ThunderboltOutlined-Z254asq-.js";import"./index-Coe5h0KH.js";import"./ToolOutlined-D4zZ6vz6.js";import"./RobotOutlined-C_sl4UcG.js";import"./index-DFWWOWsu.js";import"./ScissorOutlined-BCBnqOmY.js";import"./aiModelApi-OimFxoLW.js";import"./init-Dmth1JHB.js";function $e(t){return t}var kt=1,Ct=2,It=3,mt=4,$t=1e-6;function ti(t){return"translate("+t+",0)"}function ei(t){return"translate(0,"+t+")"}function ii(t){return e=>+t(e)}function ni(t,e){return e=Math.max(0,t.bandwidth()-e*2)/2,t.round()&&(e=Math.round(e)),i=>+t(i)+e}function si(){return!this.__axis}function ce(t,e){var i=[],n=null,a=null,h=6,d=6,S=3,I=typeof window<"u"&&window.devicePixelRatio>1?0:.5,v=t===kt||t===mt?-1:1,w=t===mt||t===Ct?"x":"y",F=t===kt||t===It?ti:ei;function x(y){var W=n??(e.ticks?e.ticks.apply(e,i):e.domain()),_=a??(e.tickFormat?e.tickFormat.apply(e,i):$e),Q=Math.max(h,0)+S,J=e.range(),j=+J[0]+I,X=+J[J.length-1]+I,H=(e.bandwidth?ni:ii)(e.copy(),I),Y=y.selection?y.selection():y,R=Y.selectAll(".domain").data([null]),P=Y.selectAll(".tick").data(W,e).order(),m=P.exit(),T=P.enter().append("g").attr("class","tick"),b=P.select("line"),k=P.select("text");R=R.merge(R.enter().insert("path",".tick").attr("class","domain").attr("stroke","currentColor")),P=P.merge(T),b=b.merge(T.append("line").attr("stroke","currentColor").attr(w+"2",v*h)),k=k.merge(T.append("text").attr("fill","currentColor").attr(w,v*Q).attr("dy",t===kt?"0em":t===It?"0.71em":"0.32em")),y!==Y&&(R=R.transition(y),P=P.transition(y),b=b.transition(y),k=k.transition(y),m=m.transition(y).attr("opacity",$t).attr("transform",function(r){return isFinite(r=H(r))?F(r+I):this.getAttribute("transform")}),T.attr("opacity",$t).attr("transform",function(r){var u=this.parentNode.__axis;return F((u&&isFinite(u=u(r))?u:H(r))+I)})),m.remove(),R.attr("d",t===mt||t===Ct?d?"M"+v*d+","+j+"H"+I+"V"+X+"H"+v*d:"M"+I+","+j+"V"+X:d?"M"+j+","+v*d+"V"+I+"H"+X+"V"+v*d:"M"+j+","+I+"H"+X),P.attr("opacity",1).attr("transform",function(r){return F(H(r)+I)}),b.attr(w+"2",v*h),k.attr(w,v*Q).text(_),Y.filter(si).attr("fill","none").attr("font-size",10).attr("font-family","sans-serif").attr("text-anchor",t===Ct?"start":t===mt?"end":"middle"),Y.each(function(){this.__axis=H})}return x.scale=function(y){return arguments.length?(e=y,x):e},x.ticks=function(){return i=Array.from(arguments),x},x.tickArguments=function(y){return arguments.length?(i=y==null?[]:Array.from(y),x):i.slice()},x.tickValues=function(y){return arguments.length?(n=y==null?null:Array.from(y),x):n&&n.slice()},x.tickFormat=function(y){return arguments.length?(a=y,x):a},x.tickSize=function(y){return arguments.length?(h=d=+y,x):h},x.tickSizeInner=function(y){return arguments.length?(h=+y,x):h},x.tickSizeOuter=function(y){return arguments.length?(d=+y,x):d},x.tickPadding=function(y){return arguments.length?(S=+y,x):S},x.offset=function(y){return arguments.length?(I=+y,x):I},x}function ri(t){return ce(kt,t)}function ai(t){return ce(It,t)}const ci=Math.PI/180,oi=180/Math.PI,xt=18,oe=.96422,le=1,ue=.82521,de=4/29,nt=6/29,fe=3*nt*nt,li=nt*nt*nt;function he(t){if(t instanceof q)return new q(t.l,t.a,t.b,t.opacity);if(t instanceof Z)return me(t);t instanceof ne||(t=Je(t));var e=At(t.r),i=At(t.g),n=At(t.b),a=Et((.2225045*e+.7168786*i+.0606169*n)/le),h,d;return e===i&&i===n?h=d=a:(h=Et((.4360747*e+.3850649*i+.1430804*n)/oe),d=Et((.0139322*e+.0971045*i+.7141733*n)/ue)),new q(116*a-16,500*(h-a),200*(a-d),t.opacity)}function ui(t,e,i,n){return arguments.length===1?he(t):new q(t,e,i,n??1)}function q(t,e,i,n){this.l=+t,this.a=+e,this.b=+i,this.opacity=+n}se(q,ui,re(ae,{brighter(t){return new q(this.l+xt*(t??1),this.a,this.b,this.opacity)},darker(t){return new q(this.l-xt*(t??1),this.a,this.b,this.opacity)},rgb(){var t=(this.l+16)/116,e=isNaN(this.a)?t:t+this.a/500,i=isNaN(this.b)?t:t-this.b/200;return e=oe*St(e),t=le*St(t),i=ue*St(i),new ne(Dt(3.1338561*e-1.6168667*t-.4906146*i),Dt(-.9787684*e+1.9161415*t+.033454*i),Dt(.0719453*e-.2289914*t+1.4052427*i),this.opacity)}}));function Et(t){return t>li?Math.pow(t,1/3):t/fe+de}function St(t){return t>nt?t*t*t:fe*(t-de)}function Dt(t){return 255*(t<=.0031308?12.92*t:1.055*Math.pow(t,1/2.4)-.055)}function At(t){return(t/=255)<=.04045?t/12.92:Math.pow((t+.055)/1.055,2.4)}function di(t){if(t instanceof Z)return new Z(t.h,t.c,t.l,t.opacity);if(t instanceof q||(t=he(t)),t.a===0&&t.b===0)return new Z(NaN,0<t.l&&t.l<100?0:NaN,t.l,t.opacity);var e=Math.atan2(t.b,t.a)*oi;return new Z(e<0?e+360:e,Math.sqrt(t.a*t.a+t.b*t.b),t.l,t.opacity)}function Ft(t,e,i,n){return arguments.length===1?di(t):new Z(t,e,i,n??1)}function Z(t,e,i,n){this.h=+t,this.c=+e,this.l=+i,this.opacity=+n}function me(t){if(isNaN(t.h))return new q(t.l,0,0,t.opacity);var e=t.h*ci;return new q(t.l,Math.cos(e)*t.c,Math.sin(e)*t.c,t.opacity)}se(Z,Ft,re(ae,{brighter(t){return new Z(this.h,this.c,this.l+xt*(t??1),this.opacity)},darker(t){return new Z(this.h,this.c,this.l-xt*(t??1),this.opacity)},rgb(){return me(this).rgb()}}));function fi(t){return function(e,i){var n=t((e=Ft(e)).h,(i=Ft(i)).h),a=_t(e.c,i.c),h=_t(e.l,i.l),d=_t(e.opacity,i.opacity);return function(S){return e.h=n(S),e.c=a(S),e.l=h(S),e.opacity=d(S),e+""}}}const hi=fi(Qe);var yt={exports:{}},mi=yt.exports,te;function ki(){return te||(te=1,function(t,e){(function(i,n){t.exports=n()})(mi,function(){var i="day";return function(n,a,h){var d=function(v){return v.add(4-v.isoWeekday(),i)},S=a.prototype;S.isoWeekYear=function(){return d(this).year()},S.isoWeek=function(v){if(!this.$utils().u(v))return this.add(7*(v-this.isoWeek()),i);var w,F,x,y,W=d(this),_=(w=this.isoWeekYear(),F=this.$u,x=(F?h.utc:h)().year(w).startOf("year"),y=4-x.isoWeekday(),x.isoWeekday()>4&&(y+=7),x.add(y,i));return W.diff(_,"week")+1},S.isoWeekday=function(v){return this.$utils().u(v)?this.day()||7:this.day(this.day()%7?v:v-7)};var I=S.startOf;S.startOf=function(v,w){var F=this.$utils(),x=!!F.u(w)||w;return F.p(v)==="isoweek"?x?this.date(this.date()-(this.isoWeekday()-1)).startOf("day"):this.date(this.date()-1-(this.isoWeekday()-1)+7).endOf("day"):I.bind(this)(v,w)}}})}(yt)),yt.exports}var yi=ki();const pi=Pe(yi);var Mt=function(){var t=function(k,r,u,f){for(u=u||{},f=k.length;f--;u[k[f]]=r);return u},e=[6,8,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,30,32,33,35,37],i=[1,25],n=[1,26],a=[1,27],h=[1,28],d=[1,29],S=[1,30],I=[1,31],v=[1,9],w=[1,10],F=[1,11],x=[1,12],y=[1,13],W=[1,14],_=[1,15],Q=[1,16],J=[1,18],j=[1,19],X=[1,20],H=[1,21],Y=[1,22],R=[1,24],P=[1,32],m={trace:function(){},yy:{},symbols_:{error:2,start:3,gantt:4,document:5,EOF:6,line:7,SPACE:8,statement:9,NL:10,weekday:11,weekday_monday:12,weekday_tuesday:13,weekday_wednesday:14,weekday_thursday:15,weekday_friday:16,weekday_saturday:17,weekday_sunday:18,dateFormat:19,inclusiveEndDates:20,topAxis:21,axisFormat:22,tickInterval:23,excludes:24,includes:25,todayMarker:26,title:27,acc_title:28,acc_title_value:29,acc_descr:30,acc_descr_value:31,acc_descr_multiline_value:32,section:33,clickStatement:34,taskTxt:35,taskData:36,click:37,callbackname:38,callbackargs:39,href:40,clickStatementDebug:41,$accept:0,$end:1},terminals_:{2:"error",4:"gantt",6:"EOF",8:"SPACE",10:"NL",12:"weekday_monday",13:"weekday_tuesday",14:"weekday_wednesday",15:"weekday_thursday",16:"weekday_friday",17:"weekday_saturday",18:"weekday_sunday",19:"dateFormat",20:"inclusiveEndDates",21:"topAxis",22:"axisFormat",23:"tickInterval",24:"excludes",25:"includes",26:"todayMarker",27:"title",28:"acc_title",29:"acc_title_value",30:"acc_descr",31:"acc_descr_value",32:"acc_descr_multiline_value",33:"section",35:"taskTxt",36:"taskData",37:"click",38:"callbackname",39:"callbackargs",40:"href"},productions_:[0,[3,3],[5,0],[5,2],[7,2],[7,1],[7,1],[7,1],[11,1],[11,1],[11,1],[11,1],[11,1],[11,1],[11,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,1],[9,2],[9,2],[9,1],[9,1],[9,1],[9,2],[34,2],[34,3],[34,3],[34,4],[34,3],[34,4],[34,2],[41,2],[41,3],[41,3],[41,4],[41,3],[41,4],[41,2]],performAction:function(r,u,f,c,p,s,V){var l=s.length-1;switch(p){case 1:return s[l-1];case 2:this.$=[];break;case 3:s[l-1].push(s[l]),this.$=s[l-1];break;case 4:case 5:this.$=s[l];break;case 6:case 7:this.$=[];break;case 8:c.setWeekday("monday");break;case 9:c.setWeekday("tuesday");break;case 10:c.setWeekday("wednesday");break;case 11:c.setWeekday("thursday");break;case 12:c.setWeekday("friday");break;case 13:c.setWeekday("saturday");break;case 14:c.setWeekday("sunday");break;case 15:c.setDateFormat(s[l].substr(11)),this.$=s[l].substr(11);break;case 16:c.enableInclusiveEndDates(),this.$=s[l].substr(18);break;case 17:c.TopAxis(),this.$=s[l].substr(8);break;case 18:c.setAxisFormat(s[l].substr(11)),this.$=s[l].substr(11);break;case 19:c.setTickInterval(s[l].substr(13)),this.$=s[l].substr(13);break;case 20:c.setExcludes(s[l].substr(9)),this.$=s[l].substr(9);break;case 21:c.setIncludes(s[l].substr(9)),this.$=s[l].substr(9);break;case 22:c.setTodayMarker(s[l].substr(12)),this.$=s[l].substr(12);break;case 24:c.setDiagramTitle(s[l].substr(6)),this.$=s[l].substr(6);break;case 25:this.$=s[l].trim(),c.setAccTitle(this.$);break;case 26:case 27:this.$=s[l].trim(),c.setAccDescription(this.$);break;case 28:c.addSection(s[l].substr(8)),this.$=s[l].substr(8);break;case 30:c.addTask(s[l-1],s[l]),this.$="task";break;case 31:this.$=s[l-1],c.setClickEvent(s[l-1],s[l],null);break;case 32:this.$=s[l-2],c.setClickEvent(s[l-2],s[l-1],s[l]);break;case 33:this.$=s[l-2],c.setClickEvent(s[l-2],s[l-1],null),c.setLink(s[l-2],s[l]);break;case 34:this.$=s[l-3],c.setClickEvent(s[l-3],s[l-2],s[l-1]),c.setLink(s[l-3],s[l]);break;case 35:this.$=s[l-2],c.setClickEvent(s[l-2],s[l],null),c.setLink(s[l-2],s[l-1]);break;case 36:this.$=s[l-3],c.setClickEvent(s[l-3],s[l-1],s[l]),c.setLink(s[l-3],s[l-2]);break;case 37:this.$=s[l-1],c.setLink(s[l-1],s[l]);break;case 38:case 44:this.$=s[l-1]+" "+s[l];break;case 39:case 40:case 42:this.$=s[l-2]+" "+s[l-1]+" "+s[l];break;case 41:case 43:this.$=s[l-3]+" "+s[l-2]+" "+s[l-1]+" "+s[l];break}},table:[{3:1,4:[1,2]},{1:[3]},t(e,[2,2],{5:3}),{6:[1,4],7:5,8:[1,6],9:7,10:[1,8],11:17,12:i,13:n,14:a,15:h,16:d,17:S,18:I,19:v,20:w,21:F,22:x,23:y,24:W,25:_,26:Q,27:J,28:j,30:X,32:H,33:Y,34:23,35:R,37:P},t(e,[2,7],{1:[2,1]}),t(e,[2,3]),{9:33,11:17,12:i,13:n,14:a,15:h,16:d,17:S,18:I,19:v,20:w,21:F,22:x,23:y,24:W,25:_,26:Q,27:J,28:j,30:X,32:H,33:Y,34:23,35:R,37:P},t(e,[2,5]),t(e,[2,6]),t(e,[2,15]),t(e,[2,16]),t(e,[2,17]),t(e,[2,18]),t(e,[2,19]),t(e,[2,20]),t(e,[2,21]),t(e,[2,22]),t(e,[2,23]),t(e,[2,24]),{29:[1,34]},{31:[1,35]},t(e,[2,27]),t(e,[2,28]),t(e,[2,29]),{36:[1,36]},t(e,[2,8]),t(e,[2,9]),t(e,[2,10]),t(e,[2,11]),t(e,[2,12]),t(e,[2,13]),t(e,[2,14]),{38:[1,37],40:[1,38]},t(e,[2,4]),t(e,[2,25]),t(e,[2,26]),t(e,[2,30]),t(e,[2,31],{39:[1,39],40:[1,40]}),t(e,[2,37],{38:[1,41]}),t(e,[2,32],{40:[1,42]}),t(e,[2,33]),t(e,[2,35],{39:[1,43]}),t(e,[2,34]),t(e,[2,36])],defaultActions:{},parseError:function(r,u){if(u.recoverable)this.trace(r);else{var f=new Error(r);throw f.hash=u,f}},parse:function(r){var u=this,f=[0],c=[],p=[null],s=[],V=this.table,l="",o=0,g=0,M=2,E=1,D=s.slice.call(arguments,1),C=Object.create(this.lexer),A={yy:{}};for(var at in this.yy)Object.prototype.hasOwnProperty.call(this.yy,at)&&(A.yy[at]=this.yy[at]);C.setInput(r,A.yy),A.yy.lexer=C,A.yy.parser=this,typeof C.yylloc>"u"&&(C.yylloc={});var ct=C.yylloc;s.push(ct);var _e=C.options&&C.options.ranges;typeof A.yy.parseError=="function"?this.parseError=A.yy.parseError:this.parseError=Object.getPrototypeOf(this).parseError;function Ce(){var G;return G=c.pop()||C.lex()||E,typeof G!="number"&&(G instanceof Array&&(c=G,G=c.pop()),G=u.symbols_[G]||G),G}for(var O,$,z,vt,et={},dt,U,Xt,ft;;){if($=f[f.length-1],this.defaultActions[$]?z=this.defaultActions[$]:((O===null||typeof O>"u")&&(O=Ce()),z=V[$]&&V[$][O]),typeof z>"u"||!z.length||!z[0]){var wt="";ft=[];for(dt in V[$])this.terminals_[dt]&&dt>M&&ft.push("'"+this.terminals_[dt]+"'");C.showPosition?wt="Parse error on line "+(o+1)+`:
`+C.showPosition()+`
Expecting `+ft.join(", ")+", got '"+(this.terminals_[O]||O)+"'":wt="Parse error on line "+(o+1)+": Unexpected "+(O==E?"end of input":"'"+(this.terminals_[O]||O)+"'"),this.parseError(wt,{text:C.match,token:this.terminals_[O]||O,line:C.yylineno,loc:ct,expected:ft})}if(z[0]instanceof Array&&z.length>1)throw new Error("Parse Error: multiple actions possible at state: "+$+", token: "+O);switch(z[0]){case 1:f.push(O),p.push(C.yytext),s.push(C.yylloc),f.push(z[1]),O=null,g=C.yyleng,l=C.yytext,o=C.yylineno,ct=C.yylloc;break;case 2:if(U=this.productions_[z[1]][1],et.$=p[p.length-U],et._$={first_line:s[s.length-(U||1)].first_line,last_line:s[s.length-1].last_line,first_column:s[s.length-(U||1)].first_column,last_column:s[s.length-1].last_column},_e&&(et._$.range=[s[s.length-(U||1)].range[0],s[s.length-1].range[1]]),vt=this.performAction.apply(et,[l,g,o,A.yy,z[1],p,s].concat(D)),typeof vt<"u")return vt;U&&(f=f.slice(0,-1*U*2),p=p.slice(0,-1*U),s=s.slice(0,-1*U)),f.push(this.productions_[z[1]][0]),p.push(et.$),s.push(et._$),Xt=V[f[f.length-2]][f[f.length-1]],f.push(Xt);break;case 3:return!0}}return!0}},T=function(){var k={EOF:1,parseError:function(u,f){if(this.yy.parser)this.yy.parser.parseError(u,f);else throw new Error(u)},setInput:function(r,u){return this.yy=u||this.yy||{},this._input=r,this._more=this._backtrack=this.done=!1,this.yylineno=this.yyleng=0,this.yytext=this.matched=this.match="",this.conditionStack=["INITIAL"],this.yylloc={first_line:1,first_column:0,last_line:1,last_column:0},this.options.ranges&&(this.yylloc.range=[0,0]),this.offset=0,this},input:function(){var r=this._input[0];this.yytext+=r,this.yyleng++,this.offset++,this.match+=r,this.matched+=r;var u=r.match(/(?:\r\n?|\n).*/g);return u?(this.yylineno++,this.yylloc.last_line++):this.yylloc.last_column++,this.options.ranges&&this.yylloc.range[1]++,this._input=this._input.slice(1),r},unput:function(r){var u=r.length,f=r.split(/(?:\r\n?|\n)/g);this._input=r+this._input,this.yytext=this.yytext.substr(0,this.yytext.length-u),this.offset-=u;var c=this.match.split(/(?:\r\n?|\n)/g);this.match=this.match.substr(0,this.match.length-1),this.matched=this.matched.substr(0,this.matched.length-1),f.length-1&&(this.yylineno-=f.length-1);var p=this.yylloc.range;return this.yylloc={first_line:this.yylloc.first_line,last_line:this.yylineno+1,first_column:this.yylloc.first_column,last_column:f?(f.length===c.length?this.yylloc.first_column:0)+c[c.length-f.length].length-f[0].length:this.yylloc.first_column-u},this.options.ranges&&(this.yylloc.range=[p[0],p[0]+this.yyleng-u]),this.yyleng=this.yytext.length,this},more:function(){return this._more=!0,this},reject:function(){if(this.options.backtrack_lexer)this._backtrack=!0;else return this.parseError("Lexical error on line "+(this.yylineno+1)+`. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
`+this.showPosition(),{text:"",token:null,line:this.yylineno});return this},less:function(r){this.unput(this.match.slice(r))},pastInput:function(){var r=this.matched.substr(0,this.matched.length-this.match.length);return(r.length>20?"...":"")+r.substr(-20).replace(/\n/g,"")},upcomingInput:function(){var r=this.match;return r.length<20&&(r+=this._input.substr(0,20-r.length)),(r.substr(0,20)+(r.length>20?"...":"")).replace(/\n/g,"")},showPosition:function(){var r=this.pastInput(),u=new Array(r.length+1).join("-");return r+this.upcomingInput()+`
`+u+"^"},test_match:function(r,u){var f,c,p;if(this.options.backtrack_lexer&&(p={yylineno:this.yylineno,yylloc:{first_line:this.yylloc.first_line,last_line:this.last_line,first_column:this.yylloc.first_column,last_column:this.yylloc.last_column},yytext:this.yytext,match:this.match,matches:this.matches,matched:this.matched,yyleng:this.yyleng,offset:this.offset,_more:this._more,_input:this._input,yy:this.yy,conditionStack:this.conditionStack.slice(0),done:this.done},this.options.ranges&&(p.yylloc.range=this.yylloc.range.slice(0))),c=r[0].match(/(?:\r\n?|\n).*/g),c&&(this.yylineno+=c.length),this.yylloc={first_line:this.yylloc.last_line,last_line:this.yylineno+1,first_column:this.yylloc.last_column,last_column:c?c[c.length-1].length-c[c.length-1].match(/\r?\n?/)[0].length:this.yylloc.last_column+r[0].length},this.yytext+=r[0],this.match+=r[0],this.matches=r,this.yyleng=this.yytext.length,this.options.ranges&&(this.yylloc.range=[this.offset,this.offset+=this.yyleng]),this._more=!1,this._backtrack=!1,this._input=this._input.slice(r[0].length),this.matched+=r[0],f=this.performAction.call(this,this.yy,this,u,this.conditionStack[this.conditionStack.length-1]),this.done&&this._input&&(this.done=!1),f)return f;if(this._backtrack){for(var s in p)this[s]=p[s];return!1}return!1},next:function(){if(this.done)return this.EOF;this._input||(this.done=!0);var r,u,f,c;this._more||(this.yytext="",this.match="");for(var p=this._currentRules(),s=0;s<p.length;s++)if(f=this._input.match(this.rules[p[s]]),f&&(!u||f[0].length>u[0].length)){if(u=f,c=s,this.options.backtrack_lexer){if(r=this.test_match(f,p[s]),r!==!1)return r;if(this._backtrack){u=!1;continue}else return!1}else if(!this.options.flex)break}return u?(r=this.test_match(u,p[c]),r!==!1?r:!1):this._input===""?this.EOF:this.parseError("Lexical error on line "+(this.yylineno+1)+`. Unrecognized text.
`+this.showPosition(),{text:"",token:null,line:this.yylineno})},lex:function(){var u=this.next();return u||this.lex()},begin:function(u){this.conditionStack.push(u)},popState:function(){var u=this.conditionStack.length-1;return u>0?this.conditionStack.pop():this.conditionStack[0]},_currentRules:function(){return this.conditionStack.length&&this.conditionStack[this.conditionStack.length-1]?this.conditions[this.conditionStack[this.conditionStack.length-1]].rules:this.conditions.INITIAL.rules},topState:function(u){return u=this.conditionStack.length-1-Math.abs(u||0),u>=0?this.conditionStack[u]:"INITIAL"},pushState:function(u){this.begin(u)},stateStackSize:function(){return this.conditionStack.length},options:{"case-insensitive":!0},performAction:function(u,f,c,p){switch(c){case 0:return this.begin("open_directive"),"open_directive";case 1:return this.begin("acc_title"),28;case 2:return this.popState(),"acc_title_value";case 3:return this.begin("acc_descr"),30;case 4:return this.popState(),"acc_descr_value";case 5:this.begin("acc_descr_multiline");break;case 6:this.popState();break;case 7:return"acc_descr_multiline_value";case 8:break;case 9:break;case 10:break;case 11:return 10;case 12:break;case 13:break;case 14:this.begin("href");break;case 15:this.popState();break;case 16:return 40;case 17:this.begin("callbackname");break;case 18:this.popState();break;case 19:this.popState(),this.begin("callbackargs");break;case 20:return 38;case 21:this.popState();break;case 22:return 39;case 23:this.begin("click");break;case 24:this.popState();break;case 25:return 37;case 26:return 4;case 27:return 19;case 28:return 20;case 29:return 21;case 30:return 22;case 31:return 23;case 32:return 25;case 33:return 24;case 34:return 26;case 35:return 12;case 36:return 13;case 37:return 14;case 38:return 15;case 39:return 16;case 40:return 17;case 41:return 18;case 42:return"date";case 43:return 27;case 44:return"accDescription";case 45:return 33;case 46:return 35;case 47:return 36;case 48:return":";case 49:return 6;case 50:return"INVALID"}},rules:[/^(?:%%\{)/i,/^(?:accTitle\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*:\s*)/i,/^(?:(?!\n||)*[^\n]*)/i,/^(?:accDescr\s*\{\s*)/i,/^(?:[\}])/i,/^(?:[^\}]*)/i,/^(?:%%(?!\{)*[^\n]*)/i,/^(?:[^\}]%%*[^\n]*)/i,/^(?:%%*[^\n]*[\n]*)/i,/^(?:[\n]+)/i,/^(?:\s+)/i,/^(?:%[^\n]*)/i,/^(?:href[\s]+["])/i,/^(?:["])/i,/^(?:[^"]*)/i,/^(?:call[\s]+)/i,/^(?:\([\s]*\))/i,/^(?:\()/i,/^(?:[^(]*)/i,/^(?:\))/i,/^(?:[^)]*)/i,/^(?:click[\s]+)/i,/^(?:[\s\n])/i,/^(?:[^\s\n]*)/i,/^(?:gantt\b)/i,/^(?:dateFormat\s[^#\n;]+)/i,/^(?:inclusiveEndDates\b)/i,/^(?:topAxis\b)/i,/^(?:axisFormat\s[^#\n;]+)/i,/^(?:tickInterval\s[^#\n;]+)/i,/^(?:includes\s[^#\n;]+)/i,/^(?:excludes\s[^#\n;]+)/i,/^(?:todayMarker\s[^\n;]+)/i,/^(?:weekday\s+monday\b)/i,/^(?:weekday\s+tuesday\b)/i,/^(?:weekday\s+wednesday\b)/i,/^(?:weekday\s+thursday\b)/i,/^(?:weekday\s+friday\b)/i,/^(?:weekday\s+saturday\b)/i,/^(?:weekday\s+sunday\b)/i,/^(?:\d\d\d\d-\d\d-\d\d\b)/i,/^(?:title\s[^\n]+)/i,/^(?:accDescription\s[^#\n;]+)/i,/^(?:section\s[^\n]+)/i,/^(?:[^:\n]+)/i,/^(?::[^#\n;]+)/i,/^(?::)/i,/^(?:$)/i,/^(?:.)/i],conditions:{acc_descr_multiline:{rules:[6,7],inclusive:!1},acc_descr:{rules:[4],inclusive:!1},acc_title:{rules:[2],inclusive:!1},callbackargs:{rules:[21,22],inclusive:!1},callbackname:{rules:[18,19,20],inclusive:!1},href:{rules:[15,16],inclusive:!1},click:{rules:[24,25],inclusive:!1},INITIAL:{rules:[0,1,3,5,8,9,10,11,12,13,14,17,23,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50],inclusive:!0}}};return k}();m.lexer=T;function b(){this.yy={}}return b.prototype=m,m.Parser=b,new b}();Mt.parser=Mt;const gi=Mt;N.extend(pi);N.extend(Oe);N.extend(ze);let B="",Nt="",Pt,Ot="",ot=[],lt=[],zt={},Rt=[],Tt=[],rt="",Yt="";const ke=["active","done","crit","milestone"];let Bt=[],ut=!1,qt=!1,jt="sunday",Lt=0;const bi=function(){Rt=[],Tt=[],rt="",Bt=[],pt=0,Wt=void 0,gt=void 0,L=[],B="",Nt="",Yt="",Pt=void 0,Ot="",ot=[],lt=[],ut=!1,qt=!1,Lt=0,zt={},We(),jt="sunday"},xi=function(t){Nt=t},Ti=function(){return Nt},vi=function(t){Pt=t},wi=function(){return Pt},_i=function(t){Ot=t},Ci=function(){return Ot},Ei=function(t){B=t},Si=function(){ut=!0},Di=function(){return ut},Ai=function(){qt=!0},Ii=function(){return qt},Fi=function(t){Yt=t},Mi=function(){return Yt},Li=function(){return B},Vi=function(t){ot=t.toLowerCase().split(/[\s,]+/)},Wi=function(){return ot},Ni=function(t){lt=t.toLowerCase().split(/[\s,]+/)},Pi=function(){return lt},Oi=function(){return zt},zi=function(t){rt=t,Rt.push(t)},Ri=function(){return Rt},Yi=function(){let t=ee();const e=10;let i=0;for(;!t&&i<e;)t=ee(),i++;return Tt=L,Tt},ye=function(t,e,i,n){return n.includes(t.format(e.trim()))?!1:t.isoWeekday()>=6&&i.includes("weekends")||i.includes(t.format("dddd").toLowerCase())?!0:i.includes(t.format(e.trim()))},Bi=function(t){jt=t},qi=function(){return jt},pe=function(t,e,i,n){if(!i.length||t.manualEndTime)return;let a;t.startTime instanceof Date?a=N(t.startTime):a=N(t.startTime,e,!0),a=a.add(1,"d");let h;t.endTime instanceof Date?h=N(t.endTime):h=N(t.endTime,e,!0);const[d,S]=ji(a,h,e,i,n);t.endTime=d.toDate(),t.renderEndTime=S},ji=function(t,e,i,n,a){let h=!1,d=null;for(;t<=e;)h||(d=e.toDate()),h=ye(t,i,n,a),h&&(e=e.add(1,"d")),t=t.add(1,"d");return[e,d]},Vt=function(t,e,i){i=i.trim();const a=/^after\s+(?<ids>[\d\w- ]+)/.exec(i);if(a!==null){let d=null;for(const I of a.groups.ids.split(" ")){let v=tt(I);v!==void 0&&(!d||v.endTime>d.endTime)&&(d=v)}if(d)return d.endTime;const S=new Date;return S.setHours(0,0,0,0),S}let h=N(i,e.trim(),!0);if(h.isValid())return h.toDate();{bt.debug("Invalid date:"+i),bt.debug("With date format:"+e.trim());const d=new Date(i);if(d===void 0||isNaN(d.getTime())||d.getFullYear()<-1e4||d.getFullYear()>1e4)throw new Error("Invalid date:"+i);return d}},ge=function(t){const e=/^(\d+(?:\.\d+)?)([Mdhmswy]|ms)$/.exec(t.trim());return e!==null?[Number.parseFloat(e[1]),e[2]]:[NaN,"ms"]},be=function(t,e,i,n=!1){i=i.trim();const h=/^until\s+(?<ids>[\d\w- ]+)/.exec(i);if(h!==null){let w=null;for(const x of h.groups.ids.split(" ")){let y=tt(x);y!==void 0&&(!w||y.startTime<w.startTime)&&(w=y)}if(w)return w.startTime;const F=new Date;return F.setHours(0,0,0,0),F}let d=N(i,e.trim(),!0);if(d.isValid())return n&&(d=d.add(1,"d")),d.toDate();let S=N(t);const[I,v]=ge(i);if(!Number.isNaN(I)){const w=S.add(I,v);w.isValid()&&(S=w)}return S.toDate()};let pt=0;const st=function(t){return t===void 0?(pt=pt+1,"task"+pt):t},Xi=function(t,e){let i;e.substr(0,1)===":"?i=e.substr(1,e.length):i=e;const n=i.split(","),a={};we(n,a,ke);for(let d=0;d<n.length;d++)n[d]=n[d].trim();let h="";switch(n.length){case 1:a.id=st(),a.startTime=t.endTime,h=n[0];break;case 2:a.id=st(),a.startTime=Vt(void 0,B,n[0]),h=n[1];break;case 3:a.id=st(n[0]),a.startTime=Vt(void 0,B,n[1]),h=n[2];break}return h&&(a.endTime=be(a.startTime,B,h,ut),a.manualEndTime=N(h,"YYYY-MM-DD",!0).isValid(),pe(a,B,lt,ot)),a},Hi=function(t,e){let i;e.substr(0,1)===":"?i=e.substr(1,e.length):i=e;const n=i.split(","),a={};we(n,a,ke);for(let h=0;h<n.length;h++)n[h]=n[h].trim();switch(n.length){case 1:a.id=st(),a.startTime={type:"prevTaskEnd",id:t},a.endTime={data:n[0]};break;case 2:a.id=st(),a.startTime={type:"getStartDate",startData:n[0]},a.endTime={data:n[1]};break;case 3:a.id=st(n[0]),a.startTime={type:"getStartDate",startData:n[1]},a.endTime={data:n[2]};break}return a};let Wt,gt,L=[];const xe={},Ui=function(t,e){const i={section:rt,type:rt,processed:!1,manualEndTime:!1,renderEndTime:null,raw:{data:e},task:t,classes:[]},n=Hi(gt,e);i.raw.startTime=n.startTime,i.raw.endTime=n.endTime,i.id=n.id,i.prevTaskId=gt,i.active=n.active,i.done=n.done,i.crit=n.crit,i.milestone=n.milestone,i.order=Lt,Lt++;const a=L.push(i);gt=i.id,xe[i.id]=a-1},tt=function(t){const e=xe[t];return L[e]},Gi=function(t,e){const i={section:rt,type:rt,description:t,task:t,classes:[]},n=Xi(Wt,e);i.startTime=n.startTime,i.endTime=n.endTime,i.id=n.id,i.active=n.active,i.done=n.done,i.crit=n.crit,i.milestone=n.milestone,Wt=i,Tt.push(i)},ee=function(){const t=function(i){const n=L[i];let a="";switch(L[i].raw.startTime.type){case"prevTaskEnd":{const h=tt(n.prevTaskId);n.startTime=h.endTime;break}case"getStartDate":a=Vt(void 0,B,L[i].raw.startTime.startData),a&&(L[i].startTime=a);break}return L[i].startTime&&(L[i].endTime=be(L[i].startTime,B,L[i].raw.endTime.data,ut),L[i].endTime&&(L[i].processed=!0,L[i].manualEndTime=N(L[i].raw.endTime.data,"YYYY-MM-DD",!0).isValid(),pe(L[i],B,lt,ot))),L[i].processed};let e=!0;for(const[i,n]of L.entries())t(i),e=e&&n.processed;return e},Ki=function(t,e){let i=e;it().securityLevel!=="loose"&&(i=Ve.sanitizeUrl(e)),t.split(",").forEach(function(n){tt(n)!==void 0&&(ve(n,()=>{window.open(i,"_self")}),zt[n]=i)}),Te(t,"clickable")},Te=function(t,e){t.split(",").forEach(function(i){let n=tt(i);n!==void 0&&n.classes.push(e)})},Zi=function(t,e,i){if(it().securityLevel!=="loose"||e===void 0)return;let n=[];if(typeof i=="string"){n=i.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);for(let h=0;h<n.length;h++){let d=n[h].trim();d.charAt(0)==='"'&&d.charAt(d.length-1)==='"'&&(d=d.substr(1,d.length-2)),n[h]=d}}n.length===0&&n.push(t),tt(t)!==void 0&&ve(t,()=>{Ne.runFunc(e,...n)})},ve=function(t,e){Bt.push(function(){const i=document.querySelector(`[id="${t}"]`);i!==null&&i.addEventListener("click",function(){e()})},function(){const i=document.querySelector(`[id="${t}-text"]`);i!==null&&i.addEventListener("click",function(){e()})})},Ji=function(t,e,i){t.split(",").forEach(function(n){Zi(n,e,i)}),Te(t,"clickable")},Qi=function(t){Bt.forEach(function(e){e(t)})},$i={getConfig:()=>it().gantt,clear:bi,setDateFormat:Ei,getDateFormat:Li,enableInclusiveEndDates:Si,endDatesAreInclusive:Di,enableTopAxis:Ai,topAxisEnabled:Ii,setAxisFormat:xi,getAxisFormat:Ti,setTickInterval:vi,getTickInterval:wi,setTodayMarker:_i,getTodayMarker:Ci,setAccTitle:Fe,getAccTitle:Ie,setDiagramTitle:Ae,getDiagramTitle:De,setDisplayMode:Fi,getDisplayMode:Mi,setAccDescription:Se,getAccDescription:Ee,addSection:zi,getSections:Ri,getTasks:Yi,addTask:Ui,findTaskById:tt,addTaskOrg:Gi,setIncludes:Vi,getIncludes:Wi,setExcludes:Ni,getExcludes:Pi,setClickEvent:Ji,setLink:Ki,getLinks:Oi,bindFunctions:Qi,parseDuration:ge,isInvalidDate:ye,setWeekday:Bi,getWeekday:qi};function we(t,e,i){let n=!0;for(;n;)n=!1,i.forEach(function(a){const h="^\\s*"+a+"\\s*$",d=new RegExp(h);t[0].match(d)&&(e[a]=!0,t.shift(1),n=!0)})}const tn=function(){bt.debug("Something is calling, setConf, remove the call")},ie={monday:Ke,tuesday:Ge,wednesday:Ue,thursday:He,friday:Xe,saturday:je,sunday:qe},en=(t,e)=>{let i=[...t].map(()=>-1/0),n=[...t].sort((h,d)=>h.startTime-d.startTime||h.order-d.order),a=0;for(const h of n)for(let d=0;d<i.length;d++)if(h.startTime>=i[d]){i[d]=h.endTime,h.order=d+e,d>a&&(a=d);break}return a};let K;const nn=function(t,e,i,n){const a=it().gantt,h=it().securityLevel;let d;h==="sandbox"&&(d=ht("#i"+e));const S=h==="sandbox"?ht(d.nodes()[0].contentDocument.body):ht("body"),I=h==="sandbox"?d.nodes()[0].contentDocument:document,v=I.getElementById(e);K=v.parentElement.offsetWidth,K===void 0&&(K=1200),a.useWidth!==void 0&&(K=a.useWidth);const w=n.db.getTasks();let F=[];for(const m of w)F.push(m.type);F=P(F);const x={};let y=2*a.topPadding;if(n.db.getDisplayMode()==="compact"||a.displayMode==="compact"){const m={};for(const b of w)m[b.section]===void 0?m[b.section]=[b]:m[b.section].push(b);let T=0;for(const b of Object.keys(m)){const k=en(m[b],T)+1;T+=k,y+=k*(a.barHeight+a.barGap),x[b]=k}}else{y+=w.length*(a.barHeight+a.barGap);for(const m of F)x[m]=w.filter(T=>T.type===m).length}v.setAttribute("viewBox","0 0 "+K+" "+y);const W=S.select(`[id="${e}"]`),_=Re().domain([Ye(w,function(m){return m.startTime}),Be(w,function(m){return m.endTime})]).rangeRound([0,K-a.leftPadding-a.rightPadding]);function Q(m,T){const b=m.startTime,k=T.startTime;let r=0;return b>k?r=1:b<k&&(r=-1),r}w.sort(Q),J(w,K,y),Me(W,y,K,a.useMaxWidth),W.append("text").text(n.db.getDiagramTitle()).attr("x",K/2).attr("y",a.titleTopMargin).attr("class","titleText");function J(m,T,b){const k=a.barHeight,r=k+a.barGap,u=a.topPadding,f=a.leftPadding,c=Ze().domain([0,F.length]).range(["#00B9FA","#F95002"]).interpolate(hi);X(r,u,f,T,b,m,n.db.getExcludes(),n.db.getIncludes()),H(f,u,T,b),j(m,r,u,f,k,c,T),Y(r,u),R(f,u,T,b)}function j(m,T,b,k,r,u,f){const p=[...new Set(m.map(o=>o.order))].map(o=>m.find(g=>g.order===o));W.append("g").selectAll("rect").data(p).enter().append("rect").attr("x",0).attr("y",function(o,g){return g=o.order,g*T+b-2}).attr("width",function(){return f-a.rightPadding/2}).attr("height",T).attr("class",function(o){for(const[g,M]of F.entries())if(o.type===M)return"section section"+g%a.numberSectionStyles;return"section section0"});const s=W.append("g").selectAll("rect").data(m).enter(),V=n.db.getLinks();if(s.append("rect").attr("id",function(o){return o.id}).attr("rx",3).attr("ry",3).attr("x",function(o){return o.milestone?_(o.startTime)+k+.5*(_(o.endTime)-_(o.startTime))-.5*r:_(o.startTime)+k}).attr("y",function(o,g){return g=o.order,g*T+b}).attr("width",function(o){return o.milestone?r:_(o.renderEndTime||o.endTime)-_(o.startTime)}).attr("height",r).attr("transform-origin",function(o,g){return g=o.order,(_(o.startTime)+k+.5*(_(o.endTime)-_(o.startTime))).toString()+"px "+(g*T+b+.5*r).toString()+"px"}).attr("class",function(o){const g="task";let M="";o.classes.length>0&&(M=o.classes.join(" "));let E=0;for(const[C,A]of F.entries())o.type===A&&(E=C%a.numberSectionStyles);let D="";return o.active?o.crit?D+=" activeCrit":D=" active":o.done?o.crit?D=" doneCrit":D=" done":o.crit&&(D+=" crit"),D.length===0&&(D=" task"),o.milestone&&(D=" milestone "+D),D+=E,D+=" "+M,g+D}),s.append("text").attr("id",function(o){return o.id+"-text"}).text(function(o){return o.task}).attr("font-size",a.fontSize).attr("x",function(o){let g=_(o.startTime),M=_(o.renderEndTime||o.endTime);o.milestone&&(g+=.5*(_(o.endTime)-_(o.startTime))-.5*r),o.milestone&&(M=g+r);const E=this.getBBox().width;return E>M-g?M+E+1.5*a.leftPadding>f?g+k-5:M+k+5:(M-g)/2+g+k}).attr("y",function(o,g){return g=o.order,g*T+a.barHeight/2+(a.fontSize/2-2)+b}).attr("text-height",r).attr("class",function(o){const g=_(o.startTime);let M=_(o.endTime);o.milestone&&(M=g+r);const E=this.getBBox().width;let D="";o.classes.length>0&&(D=o.classes.join(" "));let C=0;for(const[at,ct]of F.entries())o.type===ct&&(C=at%a.numberSectionStyles);let A="";return o.active&&(o.crit?A="activeCritText"+C:A="activeText"+C),o.done?o.crit?A=A+" doneCritText"+C:A=A+" doneText"+C:o.crit&&(A=A+" critText"+C),o.milestone&&(A+=" milestoneText"),E>M-g?M+E+1.5*a.leftPadding>f?D+" taskTextOutsideLeft taskTextOutside"+C+" "+A:D+" taskTextOutsideRight taskTextOutside"+C+" "+A+" width-"+E:D+" taskText taskText"+C+" "+A+" width-"+E}),it().securityLevel==="sandbox"){let o;o=ht("#i"+e);const g=o.nodes()[0].contentDocument;s.filter(function(M){return V[M.id]!==void 0}).each(function(M){var E=g.querySelector("#"+M.id),D=g.querySelector("#"+M.id+"-text");const C=E.parentNode;var A=g.createElement("a");A.setAttribute("xlink:href",V[M.id]),A.setAttribute("target","_top"),C.appendChild(A),A.appendChild(E),A.appendChild(D)})}}function X(m,T,b,k,r,u,f,c){if(f.length===0&&c.length===0)return;let p,s;for(const{startTime:E,endTime:D}of u)(p===void 0||E<p)&&(p=E),(s===void 0||D>s)&&(s=D);if(!p||!s)return;if(N(s).diff(N(p),"year")>5){bt.warn("The difference between the min and max time is more than 5 years. This will cause performance issues. Skipping drawing exclude days.");return}const V=n.db.getDateFormat(),l=[];let o=null,g=N(p);for(;g.valueOf()<=s;)n.db.isInvalidDate(g,V,f,c)?o?o.end=g:o={start:g,end:g}:o&&(l.push(o),o=null),g=g.add(1,"d");W.append("g").selectAll("rect").data(l).enter().append("rect").attr("id",function(E){return"exclude-"+E.start.format("YYYY-MM-DD")}).attr("x",function(E){return _(E.start)+b}).attr("y",a.gridLineStartPadding).attr("width",function(E){const D=E.end.add(1,"day");return _(D)-_(E.start)}).attr("height",r-T-a.gridLineStartPadding).attr("transform-origin",function(E,D){return(_(E.start)+b+.5*(_(E.end)-_(E.start))).toString()+"px "+(D*m+.5*r).toString()+"px"}).attr("class","exclude-range")}function H(m,T,b,k){let r=ai(_).tickSize(-k+T+a.gridLineStartPadding).tickFormat(Ht(n.db.getAxisFormat()||a.axisFormat||"%Y-%m-%d"));const f=/^([1-9]\d*)(millisecond|second|minute|hour|day|week|month)$/.exec(n.db.getTickInterval()||a.tickInterval);if(f!==null){const c=f[1],p=f[2],s=n.db.getWeekday()||a.weekday;switch(p){case"millisecond":r.ticks(Qt.every(c));break;case"second":r.ticks(Jt.every(c));break;case"minute":r.ticks(Zt.every(c));break;case"hour":r.ticks(Kt.every(c));break;case"day":r.ticks(Gt.every(c));break;case"week":r.ticks(ie[s].every(c));break;case"month":r.ticks(Ut.every(c));break}}if(W.append("g").attr("class","grid").attr("transform","translate("+m+", "+(k-50)+")").call(r).selectAll("text").style("text-anchor","middle").attr("fill","#000").attr("stroke","none").attr("font-size",10).attr("dy","1em"),n.db.topAxisEnabled()||a.topAxis){let c=ri(_).tickSize(-k+T+a.gridLineStartPadding).tickFormat(Ht(n.db.getAxisFormat()||a.axisFormat||"%Y-%m-%d"));if(f!==null){const p=f[1],s=f[2],V=n.db.getWeekday()||a.weekday;switch(s){case"millisecond":c.ticks(Qt.every(p));break;case"second":c.ticks(Jt.every(p));break;case"minute":c.ticks(Zt.every(p));break;case"hour":c.ticks(Kt.every(p));break;case"day":c.ticks(Gt.every(p));break;case"week":c.ticks(ie[V].every(p));break;case"month":c.ticks(Ut.every(p));break}}W.append("g").attr("class","grid").attr("transform","translate("+m+", "+T+")").call(c).selectAll("text").style("text-anchor","middle").attr("fill","#000").attr("stroke","none").attr("font-size",10)}}function Y(m,T){let b=0;const k=Object.keys(x).map(r=>[r,x[r]]);W.append("g").selectAll("text").data(k).enter().append(function(r){const u=r[0].split(Le.lineBreakRegex),f=-(u.length-1)/2,c=I.createElementNS("http://www.w3.org/2000/svg","text");c.setAttribute("dy",f+"em");for(const[p,s]of u.entries()){const V=I.createElementNS("http://www.w3.org/2000/svg","tspan");V.setAttribute("alignment-baseline","central"),V.setAttribute("x","10"),p>0&&V.setAttribute("dy","1em"),V.textContent=s,c.appendChild(V)}return c}).attr("x",10).attr("y",function(r,u){if(u>0)for(let f=0;f<u;f++)return b+=k[u-1][1],r[1]*m/2+b*m+T;else return r[1]*m/2+T}).attr("font-size",a.sectionFontSize).attr("class",function(r){for(const[u,f]of F.entries())if(r[0]===f)return"sectionTitle sectionTitle"+u%a.numberSectionStyles;return"sectionTitle"})}function R(m,T,b,k){const r=n.db.getTodayMarker();if(r==="off")return;const u=W.append("g").attr("class","today"),f=new Date,c=u.append("line");c.attr("x1",_(f)+m).attr("x2",_(f)+m).attr("y1",a.titleTopMargin).attr("y2",k-a.titleTopMargin).attr("class","today"),r!==""&&c.attr("style",r.replace(/,/g,";"))}function P(m){const T={},b=[];for(let k=0,r=m.length;k<r;++k)Object.prototype.hasOwnProperty.call(T,m[k])||(T[m[k]]=!0,b.push(m[k]));return b}},sn={setConf:tn,draw:nn},rn=t=>`
  .mermaid-main-font {
    font-family: var(--mermaid-font-family, "trebuchet ms", verdana, arial, sans-serif);
  }

  .exclude-range {
    fill: ${t.excludeBkgColor};
  }

  .section {
    stroke: none;
    opacity: 0.2;
  }

  .section0 {
    fill: ${t.sectionBkgColor};
  }

  .section2 {
    fill: ${t.sectionBkgColor2};
  }

  .section1,
  .section3 {
    fill: ${t.altSectionBkgColor};
    opacity: 0.2;
  }

  .sectionTitle0 {
    fill: ${t.titleColor};
  }

  .sectionTitle1 {
    fill: ${t.titleColor};
  }

  .sectionTitle2 {
    fill: ${t.titleColor};
  }

  .sectionTitle3 {
    fill: ${t.titleColor};
  }

  .sectionTitle {
    text-anchor: start;
    font-family: var(--mermaid-font-family, "trebuchet ms", verdana, arial, sans-serif);
  }


  /* Grid and axis */

  .grid .tick {
    stroke: ${t.gridColor};
    opacity: 0.8;
    shape-rendering: crispEdges;
  }

  .grid .tick text {
    font-family: ${t.fontFamily};
    fill: ${t.textColor};
  }

  .grid path {
    stroke-width: 0;
  }


  /* Today line */

  .today {
    fill: none;
    stroke: ${t.todayLineColor};
    stroke-width: 2px;
  }


  /* Task styling */

  /* Default task */

  .task {
    stroke-width: 2;
  }

  .taskText {
    text-anchor: middle;
    font-family: var(--mermaid-font-family, "trebuchet ms", verdana, arial, sans-serif);
  }

  .taskTextOutsideRight {
    fill: ${t.taskTextDarkColor};
    text-anchor: start;
    font-family: var(--mermaid-font-family, "trebuchet ms", verdana, arial, sans-serif);
  }

  .taskTextOutsideLeft {
    fill: ${t.taskTextDarkColor};
    text-anchor: end;
  }


  /* Special case clickable */

  .task.clickable {
    cursor: pointer;
  }

  .taskText.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideLeft.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }

  .taskTextOutsideRight.clickable {
    cursor: pointer;
    fill: ${t.taskTextClickableColor} !important;
    font-weight: bold;
  }


  /* Specific task settings for the sections*/

  .taskText0,
  .taskText1,
  .taskText2,
  .taskText3 {
    fill: ${t.taskTextColor};
  }

  .task0,
  .task1,
  .task2,
  .task3 {
    fill: ${t.taskBkgColor};
    stroke: ${t.taskBorderColor};
  }

  .taskTextOutside0,
  .taskTextOutside2
  {
    fill: ${t.taskTextOutsideColor};
  }

  .taskTextOutside1,
  .taskTextOutside3 {
    fill: ${t.taskTextOutsideColor};
  }


  /* Active task */

  .active0,
  .active1,
  .active2,
  .active3 {
    fill: ${t.activeTaskBkgColor};
    stroke: ${t.activeTaskBorderColor};
  }

  .activeText0,
  .activeText1,
  .activeText2,
  .activeText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Completed task */

  .done0,
  .done1,
  .done2,
  .done3 {
    stroke: ${t.doneTaskBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
  }

  .doneText0,
  .doneText1,
  .doneText2,
  .doneText3 {
    fill: ${t.taskTextDarkColor} !important;
  }


  /* Tasks on the critical line */

  .crit0,
  .crit1,
  .crit2,
  .crit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.critBkgColor};
    stroke-width: 2;
  }

  .activeCrit0,
  .activeCrit1,
  .activeCrit2,
  .activeCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.activeTaskBkgColor};
    stroke-width: 2;
  }

  .doneCrit0,
  .doneCrit1,
  .doneCrit2,
  .doneCrit3 {
    stroke: ${t.critBorderColor};
    fill: ${t.doneTaskBkgColor};
    stroke-width: 2;
    cursor: pointer;
    shape-rendering: crispEdges;
  }

  .milestone {
    transform: rotate(45deg) scale(0.8,0.8);
  }

  .milestoneText {
    font-style: italic;
  }
  .doneCritText0,
  .doneCritText1,
  .doneCritText2,
  .doneCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .activeCritText0,
  .activeCritText1,
  .activeCritText2,
  .activeCritText3 {
    fill: ${t.taskTextDarkColor} !important;
  }

  .titleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${t.titleColor||t.textColor};
    font-family: var(--mermaid-font-family, "trebuchet ms", verdana, arial, sans-serif);
  }
`,an=rn,Yn={parser:gi,db:$i,renderer:sn,styles:an};export{Yn as diagram};
