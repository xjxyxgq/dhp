import{l as r}from"./index-Dr1FW_sl.js";const e={async create(a){const t=await r("/api/v1/chat/threads",a);return t&&t.status==="ok"&&t.data?t.data:t}};export{e as t};
